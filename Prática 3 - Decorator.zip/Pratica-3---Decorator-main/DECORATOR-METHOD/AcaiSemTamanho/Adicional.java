package AcaiSemTamanho;

public interface Adicional{
    public String getDescricao();
    public double custo();
}
