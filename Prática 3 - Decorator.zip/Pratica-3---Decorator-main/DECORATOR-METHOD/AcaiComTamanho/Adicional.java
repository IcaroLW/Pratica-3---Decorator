package AcaiComTamanho;

public interface Adicional{
    public String getDescricao();
    public double custo();
    public Tamanho getTamanho();
}