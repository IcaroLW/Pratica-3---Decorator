package AcaiSemTamanho;

public class Acai implements Adicional {
    @Override
    public String getDescricao(){
        return "Açai";
    }
    @Override
    public double custo(){
        return 10;
    }
}
