package AcaiComTamanho;

public enum Tamanho {
    PEQUENO, MEDIO, GRANDE;
}